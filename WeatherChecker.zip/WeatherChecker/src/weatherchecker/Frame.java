/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package weatherchecker;

import java.awt.Color;
import java.net.Proxy;
import java.net.URL;
import java.util.Scanner;
import javax.net.ssl.HttpsURLConnection;
import javax.swing.ImageIcon;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author CK
 */
public class Frame extends javax.swing.JFrame {

    /**
     * Creates new form Frame
     */
    public Frame() {
        initComponents();
        
    }
    //Getting data from WeatherAPI
    private void Weather( String json){
        try{
            JSONParser parses = new JSONParser();
            Object obj = parses.parse(json);
            JSONObject mainobj = (JSONObject) obj;
            
            JSONObject current = (JSONObject) mainobj.get("current");
            changebackground((long) current.get("is_day"));
                                   
            JSONObject objs = (JSONObject) mainobj.get("hourly");
            
            //getting temp
            JSONArray tempo = (JSONArray) objs.get("temperature_2m");
            temp.setText(String.valueOf((double)tempo.get(0)) + "ºC");
            
            //getting humidity
            JSONArray humidity = (JSONArray) objs.get("relative_humidity_2m");
            huminity.setText(String.valueOf((long) humidity.get(0)) + "%");
            
            //getting wind speed
            JSONArray windS = (JSONArray) objs.get("wind_speed_10m");
            wind.setText(String.valueOf((double) windS.get(0)) + "Km/h");
            
            //getting weather code
            JSONArray WeatherC = (JSONArray) objs.get("weather_code");
            weather.setText(WeatherCode((long)WeatherC.get(0)));
            
            //matching the code
            switch (WeatherCode((long)WeatherC.get(0))){
                case "Clear": weathericon.setIcon(new ImageIcon("C:\\Users\\CK\\Desktop\\weather\\weatherapp_images\\clear.png"));break;
                case "Cloudy": weathericon.setIcon(new ImageIcon("C:\\Users\\CK\\Desktop\\weather\\weatherapp_images\\cloudy.png"));break;
                case "Rainy": weathericon.setIcon(new ImageIcon("C:\\Users\\CK\\Desktop\\weather\\weatherapp_images\\rain.png"));break;
                case "Snow": weathericon.setIcon(new ImageIcon("C:\\Users\\CK\\Desktop\\weather\\weatherapp_images\\snow.png"));break;
                default:break;
            }            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    //Weather Code
    private String WeatherCode(long code){
        String WeatherCodition = "";
        if(code ==0){
            //clear
            WeatherCodition = "Clear";
        }
        else if (code >=1 && code <=3){
            //cloudy
            WeatherCodition = "Cloudy";
        }
        else if (code >=51 && code<=67 || code >=80 && code<=99){
            //rainy
            WeatherCodition = "Rainy";
        }
        else if (code >=71 && code <=77){
            //snow
            WeatherCodition = "Snow";
        }
        return WeatherCodition;
    }
    //Turning Geolocation API into json
    private double[] Geolocation(String json){
        try{
            double Latitude = 0;
            double Longitude = 0;
            double location[] = new double[2];
            JSONParser parses = new JSONParser();
            Object obj = parses.parse(json);
            JSONObject mainobj = (JSONObject) obj;
            
            JSONArray array = (JSONArray) mainobj.get("results");
            for(int a = 0;a<array.size();a++){
                JSONObject lat = (JSONObject) array.get(1);
                Latitude = (double) lat.get("latitude");
                Longitude = (double) lat.get("longitude");
            }            
            if(Latitude != 0 && Longitude != 0){
                location[0] = Latitude;
                location[1] = Longitude;
            }else System.out.println("NO location found");
            
            return location;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    //getting json from weatherAPI
    private String ConnectToWeatherAPI(double Latitude,double Longitude){
        try{
            String link = "https://api.open-meteo.com/v1/forecast?latitude="+Latitude+"&longitude="+Longitude+"&current=is_day&hourly=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&forecast_days=1";
            URL url = new URL(link);
            HttpsURLConnection connect = (HttpsURLConnection) url.openConnection();
            connect.setRequestMethod("GET");
            int response = connect.getResponseCode();
            if(response == connect.HTTP_OK){
                StringBuilder sb = new StringBuilder();
                Scanner scan = new Scanner(connect.getInputStream());
                while(scan.hasNext()){
                    sb.append(scan.nextLine());
                }
                String json = sb.toString();
                return json;
            }            
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }       
    //getting json in geolocation
    private String ConnectToGeolocatinAPI(String search){
        try{
            String link = "https://geocoding-api.open-meteo.com/v1/search?name="+ search +"&count=10&language=en&format=json";
            URL url = new URL(link); 
            HttpsURLConnection connect = (HttpsURLConnection) url.openConnection();
            connect.setRequestMethod("GET");
            int response = connect.getResponseCode();
            if(response == connect.HTTP_OK){
                System.out.println("Sucessfully connected");
                StringBuilder sb = new StringBuilder();
                Scanner scan = new Scanner(connect.getInputStream());
                while(scan.hasNext()){
                    sb.append(scan.nextLine());
                }
                String json = (String) sb.toString();
                return json;
            }
            else System.out.println("Unsucessfully connected");
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    //set the background if the result is day or night
    private void changebackground(long a){
        if(a == 0){
            background.setBackground(new Color(255,246,207));           
        }
        else if (a == 1){
            background.setBackground(new Color(16,13,54));
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        background = new javax.swing.JPanel();
        search = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        weathericon = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        huminity = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        wind = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        weather = new javax.swing.JLabel();
        temp = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        background.setBackground(new java.awt.Color(204, 204, 204));

        search.setBackground(new java.awt.Color(245, 245, 245));
        search.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N

        jButton1.setBackground(new java.awt.Color(245, 245, 245));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/searchlogo-removebg-preview (2).png"))); // NOI18N
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        weathericon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/clear.png"))); // NOI18N

        javax.swing.GroupLayout backgroundLayout = new javax.swing.GroupLayout(background);
        background.setLayout(backgroundLayout);
        backgroundLayout.setHorizontalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(backgroundLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(backgroundLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(weathericon)))
                .addContainerGap(7, Short.MAX_VALUE))
        );
        backgroundLayout.setVerticalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(weathericon)
                .addContainerGap())
        );

        backgroundLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton1, search});

        getContentPane().add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, -1));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/humidity.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("Huminidy");

        huminity.setFont(new java.awt.Font("MS Reference Sans Serif", 0, 24)); // NOI18N
        huminity.setForeground(new java.awt.Color(51, 51, 51));
        huminity.setText("74 %");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pictures/windspeed.png"))); // NOI18N

        wind.setFont(new java.awt.Font("MS Reference Sans Serif", 0, 24)); // NOI18N
        wind.setForeground(new java.awt.Color(51, 51, 51));
        wind.setText("24 Kmh");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 51, 51));
        jLabel9.setText("Windspeed");

        weather.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 24)); // NOI18N
        weather.setForeground(new java.awt.Color(51, 51, 51));
        weather.setText("Sunny");

        temp.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 36)); // NOI18N
        temp.setForeground(new java.awt.Color(51, 51, 51));
        temp.setText("30.1°C");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(weather)
                .addGap(167, 167, 167))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(temp)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(huminity))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(wind)
                    .addComponent(jLabel9))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(temp)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(weather)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel9)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(wind))
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(huminity)))))
                .addGap(27, 27, 27))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 419, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(!search.getText().equals("")){
            System.out.println("Loading..");
            try{
                double loc[] = Geolocation(ConnectToGeolocatinAPI(search.getText()));
                Weather(ConnectToWeatherAPI(loc[0],loc[1]));
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
        else System.out.println("Please search something first");
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Frame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel background;
    private javax.swing.JLabel huminity;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField search;
    private javax.swing.JLabel temp;
    private javax.swing.JLabel weather;
    private javax.swing.JLabel weathericon;
    private javax.swing.JLabel wind;
    // End of variables declaration//GEN-END:variables
}
